void alarm_cb (int i);
