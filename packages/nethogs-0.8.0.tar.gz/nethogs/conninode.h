// handling the connection->inode mapping
void refreshconninode ();
