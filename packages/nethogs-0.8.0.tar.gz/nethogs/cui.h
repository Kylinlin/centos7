/* NetHogs console UI */

void do_refresh ();
void init_ui ();
void exit_ui ();

/* periodically gives some CPU-time to the UI */
void ui_tick ();
